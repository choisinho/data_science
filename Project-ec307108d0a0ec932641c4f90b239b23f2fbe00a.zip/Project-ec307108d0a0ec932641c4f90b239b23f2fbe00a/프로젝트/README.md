### 종이공장 이상탐지

https://towardsdatascience.com/lstm-autoencoder-for-extreme-rare-event-classification-in-keras-ce209a224cfb


### 기상데이터 계절분석 
### 부평빌라 가격예측
### 지하철 데이터 분석
