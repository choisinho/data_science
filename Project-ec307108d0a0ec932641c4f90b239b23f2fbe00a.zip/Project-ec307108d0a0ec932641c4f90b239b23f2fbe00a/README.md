# Project

프로젝트 하나 할때마다 업로드 할 예정입니다.

챗봇 (하소연 - 고민상담 분류 및 솔루션 제공)

기상청(gs, lalavla data를 바탕으로 날씨와 유통 데이터 간의 상관관계를 바탕으로 판매량 예측)

리니지(로그 데이터를 preprocessing 을 통해 insight 발굴)

크롤링 (네이버api, natepann, 루리웹 data gathering)

키움 api 연동해서 주식시장 정보 크롤링

smart / 스마트 냉장고 - OCR을 하기 위해 pixcel link, C-RNN 을 통해 train 하고 영수증을 읽는 모델을 만듬 
        이를 통해 냉장고에 이 기술을 적용하여 냉장고 식재료 관리를 할 수 있는 방법들을 제시하여 스마트 냉장고를 만들 수 있도록 하는 것을 목표로 하고         있습니다.

groupSendSMS 소스에 error 가 있을 경우 문자로 알람 서비스를 보내기 위해 만든 소스 
